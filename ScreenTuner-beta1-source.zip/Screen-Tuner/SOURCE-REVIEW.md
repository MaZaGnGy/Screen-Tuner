# r3 actual-device review

Read-only ADB evidence: r2 installed13002; low/static min_fps144; SA calls0; lowIdle stopped by dark-mode-policy-preserved. Native VRR default TouchIdle timeout2500/gap800/software floor60. After user app transitions, native history explicitly records launcher85 vote120 and native90 promotion144.

Verified firmware methods: OplusRefreshRateCore Vote priority85=LAUNCHER_REQUEST,80=HIGH_TEMPERATURE,90=START_ANIMATION_BOOST,120=FOD_SHOW; Vote(float,String) preserves a point range/source. NativeIdle uses the actual manager handleTouchIdleConfig(boolean), isSupportHwWithHistogram(TouchIdleBean) and SFController setTouchIdleConfig(TouchIdleBean). Outgoing bean copied via its existing copy constructor; packet layout not reimplemented. Override constrained to default profile and native guards. System touch/content idle decision remains native. HW-only fast profile is experimental until hardware measurement; native software fallback remains where native HW is unavailable. No sysfs writes, service-call guesses, video observers, forced mode1, or DTBO edits.

DC behavior retained: native handleDcModeStatus only writes secure display_single_pulse_eyeprotection_switch=0. Module prevents this only for selected full-DC mode2 with eligibilitytrue, matching original code. Native DC-controller getDCLimitRefreshRateId(int) and setLimitMaxRefreshRateId(int) signatures verified against device DEX. Does not turn DC on by writing a user setting. NativeIdle DC and PWM paths do not override the selected dimming mode.

Validation:138 pure assertions +99 production callback assertions with mocked system/OEM. APK signature and alignment passed. Physical1Hz validation pending installation.
