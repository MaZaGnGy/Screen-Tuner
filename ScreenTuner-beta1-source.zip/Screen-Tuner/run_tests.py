"""Host JVM regression tests: python run_tests.py [output-directory]."""
import subprocess,sys
from pathlib import Path
r=Path(__file__).resolve().parent
out=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else r/'test-out'
out.mkdir(parents=True,exist_ok=True)
subprocess.run(['javac','--release','11','-encoding','UTF-8','-d',str(out),
    str(r/'module/src/com/refresh165/RateProfile.java'),str(r/'module/src/com/refresh165/AdaptiveState.java'),str(r/'module/src/com/refresh165/ImeLatch.java'),
    str(r/'tests/PolicyTest.java')],check=True)
subprocess.run(['java','-cp',str(out),'com.refresh165.PolicyTest'],check=True)
